# -*- coding: utf-8 -*-
"""运行全部策略自检，输出统一指标 JSON。"""
from __future__ import annotations

import importlib
import json
import sys
import time
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

MODULES = [
    "s01_pairs",
    "s02_xsec_momentum",
    "s03_tsmom",
    "s04_mean_reversion",
    "s05_factor_model",
    "s06_pca_statarb",
    "s07_market_making",
    "s08_orderbook_imbalance",
    "s09_news_sentiment",
    "s10_vol_arb",
    "s11_gbdt_alpha",
    "s12_rl_execution",
    "s13_risk_parity_kelly",
    "s14_crypto_basis",
    "s15_meta_labeling",
]


def main() -> list[dict]:
    out = []
    for name in MODULES:
        t0 = time.time()
        mod = importlib.import_module(f"strategies.{name}")
        res = mod.demo(verbose=False)
        res["module"] = name
        res["seconds"] = round(time.time() - t0, 2)
        out.append(res)
        print(f"{name:28s} sharpe={res.get('sharpe', 0):7.3f} "
              f"ann={res.get('ann_ret', 0):7.3%} note={res.get('note', '')}")

    Path("output").mkdir(exist_ok=True)
    (Path("output") / "results.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


if __name__ == "__main__":
    main()
