# -*- coding: utf-8 -*-
"""06 PCA 残差反转（Statistical Arbitrage）

原理
----
对收益矩阵做滚动 PCA，取前 k 个主成分作为共同风险因子：
    R = F L^{1/2} V^T + E
把每只股票收益中能被主成分解释的部分剥离，剩下的残差 E 做短期反转。
这是 Avellaneda & Lee (2010) 思路的简化版，也是很多 stat arb  desk
的真实工作方式：先中性化，再在残差上做均值回归。

公式
----
    B = 前 k 个特征向量（资产载荷）
    e_t = r_t - B B^T r_t
    z_t = e_t / std(e, 20)
    w = -clip(z, -3, 3)，再归一化

风险
----
主成分不稳定；残差可能包含未建模的风险因子；
高频调仓成本高；极端行情下相关性趋近 1，分散化失效。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, hold_mask, normalize_gross, rebalance_every,
                     returns_of, summarize, synthetic_prices)


def signals(returns: pd.DataFrame, n_factors: int = 3, window: int = 120,
            z_window: int = 20, every: int = 1) -> pd.DataFrame:
    cols = returns.columns
    out = pd.DataFrame(0.0, index=returns.index, columns=cols)
    R = returns.values

    for t in range(window + z_window, len(returns)):
        hist = R[t - window:t]
        mu = hist.mean(axis=0)
        cov = np.cov(hist.T)
        vals, vecs = np.linalg.eigh(cov)
        order = np.argsort(vals)[::-1][:n_factors]
        B = vecs[:, order]

        h = R[t - z_window:t] - mu
        resid_hist = h - h @ B @ B.T
        r = R[t] - mu
        resid = r - B @ (B.T @ r)

        sd = resid_hist.std(axis=0)
        z = np.divide(resid, sd, out=np.zeros_like(resid), where=sd > 1e-12)
        raw = -np.clip(z, -3.0, 3.0)
        scale = np.abs(raw).sum()
        if scale > 0:
            out.iloc[t] = raw / scale

    mask = rebalance_every(returns.index, every)
    return hold_mask(out, mask)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    w = signals(rets)
    bt = backtest(rets, w, cost_bps=2.0)
    res = summarize("PCA 残差反转", bt, note="3 因子，20 日残差 z-score，日频")
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
