# -*- coding: utf-8 -*-
"""10 期权波动率套利（Volatility Arbitrage）

原理
----
期权价格由隐含波动率（IV）决定。若 IV 系统性高于随后实现的波动率（RV），
卖出期权、用标的做 delta 对冲，可以赚取波动率风险溢价（VRP）。
经典做法：卖出 ATM 跨式（straddle），每日按 BS delta 调仓，持有到期。

公式
----
    Black-Scholes call:
      C = S N(d1) - K e^{-rT} N(d2)
      d1 = [ln(S/K) + (r + sigma^2/2)T] / (sigma sqrt(T)),  d2 = d1 - sigma sqrt(T)
    straddle delta = N(d1) + (N(d1) - 1) = 2N(d1) - 1
    VRP ≈ IV^2 - RV^2

风险
----
波动率跳跃、gap 风险、对冲频率不足、保证金与流动性；
卖出尾部风险是“捡钢镚”策略的典型形态。
"""
from __future__ import annotations

import math

import numpy as np


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def bs_price(S: float, K: float, T: float, r: float, sigma: float,
             kind: str = "call") -> float:
    if T <= 0 or sigma <= 0:
        return max(S - K, 0.0) if kind == "call" else max(K - S, 0.0)
    d1 = (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    if kind == "call":
        return S * norm_cdf(d1) - K * math.exp(-r * T) * norm_cdf(d2)
    return K * math.exp(-r * T) * norm_cdf(-d2) - S * norm_cdf(-d1)


def bs_delta(S: float, K: float, T: float, r: float, sigma: float,
             kind: str = "call") -> float:
    if T <= 0 or sigma <= 0:
        return float(S > K) if kind == "call" else float(S < K)
    d1 = (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))
    return norm_cdf(d1) if kind == "call" else norm_cdf(d1) - 1.0


def simulate(n_paths: int = 400, days: int = 21, seed: int = 5,
             S0: float = 100.0, K: float = 100.0, iv: float = 0.21,
             theta: float = 0.18, kappa: float = 3.0,
             volvol: float = 0.6) -> dict:
    rng = np.random.default_rng(seed)
    dt = 1.0 / 252.0
    pnls = np.zeros(n_paths)

    for p in range(n_paths):
        logv = math.log(theta)
        S = S0
        premium = (bs_price(S0, K, days * dt, 0.0, iv, "call")
                   + bs_price(S0, K, days * dt, 0.0, iv, "put"))
        cash = premium
        delta_prev = 0.0

        for d in range(1, days + 1):
            logv += kappa * (math.log(theta) - logv) * dt + volvol * math.sqrt(dt) * rng.normal()
            v = math.exp(logv)
            jump = rng.normal(0.0, 0.035) if rng.random() < 0.01 else 0.0
            S *= math.exp(-0.5 * v * v * dt + v * math.sqrt(dt) * rng.normal() + jump)

            tau = max((days - d) * dt, 1e-8)
            delta = (bs_delta(S, K, tau, 0.0, iv, "call")
                     + bs_delta(S, K, tau, 0.0, iv, "put"))
            cash -= (delta - delta_prev) * S
            delta_prev = delta

        cash += delta_prev * S - abs(S - K)
        pnls[p] = cash

    sharpe = float(pnls.mean() / pnls.std() * math.sqrt(252 / days)) if pnls.std() > 0 else 0.0
    return dict(name="期权波动率套利", type="仿真", ann_ret=0.0,
                ann_vol=float(pnls.std()), sharpe=sharpe, max_dd=0.0,
                turnover=0.0, mean_pnl=float(pnls.mean()),
                key=f"{pnls.mean():.2f}",
                note=f"卖出 IV={iv:.0%} 跨式，均值 PnL={pnls.mean():.2f} 美元/张")


def demo(verbose: bool = True) -> dict:
    res = simulate()
    if verbose:
        print(res)
        print("BS call:", round(bs_price(100, 100, 0.25, 0.0, 0.2), 3))
    return res


if __name__ == "__main__":
    demo()
