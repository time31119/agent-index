# -*- coding: utf-8 -*-
"""11 梯度提升树选股（GBDT Alpha）

原理
----
把横截面选股写成监督学习：特征 X（动量、反转、波动、均线偏离、成交量），
标签 y（未来 5 日收益）。用梯度提升树拟合非线性关系：
    F_m(x) = F_{m-1}(x) + nu * h_m(x)
其中 h_m 拟合负梯度（残差）。本文件用决策树桩（depth=1）实现一个
最小可运行的 GBDT，避免依赖 sklearn / xgboost。

工程要点
--------
1) 时间序列交叉验证必须 purge + embargo，防止标签泄漏；
2) 特征做截面标准化，避免市值/波动带来的尺度偏差；
3) 训练集只使用 t 时刻已经可见的标签（t-horizon 之前）。

风险
----
过拟合、特征漂移、交易成本；树模型对异常值敏感；
合成数据上的表现不能外推到真实市场。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, cs_zscore, returns_of, summarize,
                     synthetic_prices, synthetic_volume)


def build_dataset(prices: pd.DataFrame, volume: pd.DataFrame,
                  horizon: int = 5) -> tuple[np.ndarray, np.ndarray, list[str]]:
    ret = returns_of(prices)
    raw = {
        "ret1": ret,
        "ret5": prices.pct_change(5, fill_method=None),
        "ret20": prices.pct_change(20, fill_method=None),
        "ret60": prices.pct_change(60, fill_method=None),
        "vol20": ret.rolling(20).std(),
        "ma20": prices / prices.rolling(20).mean() - 1.0,
        "volz": (volume - volume.rolling(60).mean()) / volume.rolling(60).std(),
    }
    # 特征做截面标准化，剥离市场/规模等共同尺度
    X = np.stack([cs_zscore(f).values for f in raw.values()], axis=2).astype(float)

    # 标签用截面排名而不是原始收益，避免模型去预测市场 beta
    fwd = prices.shift(-horizon) / prices - 1.0
    y = (fwd.rank(axis=1, pct=True) - 0.5).values.astype(float)
    return X, y, list(raw)


def _best_stump(X: np.ndarray, resid: np.ndarray, min_leaf: int = 40,
                n_thresholds: int = 5):
    best = None
    n, p = X.shape
    for j in range(p):
        qs = np.unique(np.quantile(X[:, j], np.linspace(0.15, 0.85, n_thresholds)))
        for th in qs:
            left = X[:, j] <= th
            nl = int(left.sum())
            if nl < min_leaf or n - nl < min_leaf:
                continue
            ml = float(resid[left].mean())
            mr = float(resid[~left].mean())
            sse = float(((resid[left] - ml) ** 2).sum() + ((resid[~left] - mr) ** 2).sum())
            if best is None or sse < best[0]:
                best = (sse, j, float(th), ml, mr)
    return best


def fit_gbdt(X: np.ndarray, y: np.ndarray, n_estimators: int = 30,
             lr: float = 0.08) -> tuple[float, list]:
    base = float(y.mean())
    pred = np.full(len(y), base)
    stumps = []
    for _ in range(n_estimators):
        resid = y - pred
        best = _best_stump(X, resid)
        if best is None:
            break
        _, j, th, ml, mr = best
        pred += lr * np.where(X[:, j] <= th, ml, mr)
        stumps.append((j, th, ml, mr))
    return base, stumps


def predict_gbdt(base: float, stumps: list, X: np.ndarray, lr: float = 0.08) -> np.ndarray:
    pred = np.full(len(X), base)
    for j, th, ml, mr in stumps:
        pred += lr * np.where(X[:, j] <= th, ml, mr)
    return pred


def signals(prices: pd.DataFrame, volume: pd.DataFrame, horizon: int = 5,
            train_window: int = 500, refit: int = 120,
            n_estimators: int = 30, every: int = 5) -> pd.DataFrame:
    X, y, _ = build_dataset(prices, volume, horizon)
    T, N, F = X.shape
    w = np.zeros((T, N))
    base, stumps, last_fit = 0.0, [], -10_000

    for t in range(300, T - horizon, every):
        if t - last_fit >= refit:
            lo = max(0, t - horizon - train_window)
            Xtr = X[lo:t - horizon].reshape(-1, F)
            ytr = y[lo:t - horizon].reshape(-1)
            mask = np.isfinite(Xtr).all(axis=1) & np.isfinite(ytr)
            if mask.sum() >= 300:
                base, stumps = fit_gbdt(Xtr[mask], ytr[mask], n_estimators=n_estimators)
                last_fit = t

        pred = predict_gbdt(base, stumps, X[t])
        if not np.isfinite(pred).all():
            continue
        demeaned = pred - pred.mean()
        scale = np.abs(demeaned).sum()
        if scale > 0:
            w[t] = demeaned / scale

    w_df = pd.DataFrame(w, index=prices.index, columns=prices.columns)
    hold = pd.Series(False, index=prices.index)
    hold.iloc[300::every] = True
    return w_df.where(hold, np.nan).ffill().fillna(0.0)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    volume = synthetic_volume(prices)
    rets = returns_of(prices)
    w = signals(prices, volume)
    bt = backtest(rets, w, cost_bps=5.0)
    res = summarize("GBDT 选股", bt, note="树桩 GBDT，5 日标签，120 日重训")
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
