# -*- coding: utf-8 -*-
"""13 组合优化：风险平价与凯利公式

原理
----
预测再准，仓位错了也会亏钱。两种经典仓位方法：

1) 风险平价（Risk Parity）：让每个资产对组合风险的边际贡献相等。
   风险贡献 RC_i = w_i * (Sigma w)_i / sigma_p
   迭代求解 w_i，使 RC_i 全部相等。

2) 凯利公式（Kelly）：最大化长期对数增长。
   单资产 f* = mu / sigma^2
   多资产 f* = Sigma^{-1} mu
   实务中只用分数凯利（如 0.25~0.5 倍），并对权重设上限。

风险
----
协方差估计误差会被求逆放大；凯利对 mu 的误差极其敏感；
风险平价在相关性趋同的危机中并不“平价”。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, rebalance_every, returns_of, summarize,
                     synthetic_prices)


def risk_parity(cov: np.ndarray, iters: int = 500) -> np.ndarray:
    n = cov.shape[0]
    w = np.ones(n) / n
    for _ in range(iters):
        mrc = cov @ w
        rc = w * mrc
        target = rc.mean()
        w = w * np.sqrt(target / np.maximum(rc, 1e-14))
        w = np.maximum(w, 1e-10)
        w /= w.sum()
    return w


def kelly(cov: np.ndarray, mu: np.ndarray, fraction: float = 0.5,
          cap: float = 1.0) -> np.ndarray:
    w = np.linalg.pinv(cov) @ mu
    w = np.clip(w, -cap, cap) * fraction
    gross = np.abs(w).sum()
    return w / gross if gross > 1e-12 else np.zeros_like(w)


def weights(prices: pd.DataFrame, method: str = "rp", window: int = 120,
            every: int = 21) -> pd.DataFrame:
    ret = returns_of(prices)
    cols = prices.columns
    out = pd.DataFrame(0.0, index=prices.index, columns=cols)
    mask = rebalance_every(prices.index, every).values

    for t in range(window, len(prices)):
        if not mask[t]:
            continue
        hist = ret.iloc[t - window:t].values
        cov = np.cov(hist.T) + np.eye(len(cols)) * 1e-8
        mu = hist.mean(axis=0)
        if method == "rp":
            w = risk_parity(cov)
        elif method == "kelly":
            w = kelly(cov, mu, fraction=0.35, cap=1.0)
        else:
            w = np.ones(len(cols)) / len(cols)
        out.iloc[t] = w

    out = out.where(pd.Series(mask, index=out.index), np.nan).ffill().fillna(0.0)
    return out


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    w_rp = weights(prices, "rp")
    w_kelly = weights(prices, "kelly")
    bt_rp = backtest(rets, w_rp, cost_bps=3.0)
    bt_kelly = backtest(rets, w_kelly, cost_bps=3.0)
    res = summarize("风险平价 + 分数凯利", bt_rp, note="月度调仓；凯利用 0.35 倍")
    if verbose:
        print(res)
        print("凯利版夏普:", round(summarize("kelly", bt_kelly)["sharpe"], 3))
    return res


if __name__ == "__main__":
    demo()
