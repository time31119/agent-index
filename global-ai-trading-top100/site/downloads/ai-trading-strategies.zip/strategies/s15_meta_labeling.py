# -*- coding: utf-8 -*-
"""15 元标记（Meta-labeling）

原理
----
López de Prado 提出的二级模型框架：
  一级模型决定“方向”（做多还是做空）；
  二级模型预测“这个方向有多大概率正确”，只在概率足够高时下注，
  并据此调整仓位。它把“预测收益”拆成“方向 + 置信度”，
  能显著提高精确率、降低回撤。

流程
----
    1) primary side = sign(momentum_20)
    2) 特征 = |momentum|, vol, trend, 截面离散度
    3) 标签 = 1{side * forward_return > 0}
    4) 逻辑回归输出 p，仓位 = side * max(0, 2p - 1)

风险
----
二级模型同样会过拟合；样本不平衡；概率校准误差；
若一级模型本身没有边际，二级模型只是在拟合噪声。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, returns_of, summarize, synthetic_prices)


def build_events(prices: pd.DataFrame, horizon: int = 5) -> pd.DataFrame:
    ret = returns_of(prices)
    mom = prices.pct_change(60, fill_method=None)
    vol = ret.rolling(20).std()
    trend = prices / prices.rolling(120).mean() - 1.0
    fwd = prices.shift(-horizon) / prices - 1.0

    rows = []
    for t in range(120, len(prices) - horizon, 5):
        disp = float(mom.iloc[t].std())
        for i, col in enumerate(prices.columns):
            m, v, tr, f = mom.iloc[t, i], vol.iloc[t, i], trend.iloc[t, i], fwd.iloc[t, i]
            if not np.isfinite([m, v, tr, f]).all():
                continue
            side = 1.0 if m > 0 else -1.0
            rows.append(dict(date=prices.index[t], asset=col, side=side,
                             mom=float(m), vol=float(v), trend=float(tr),
                             disp=disp, fwd=float(f),
                             label=int(side * f > 0)))
    return pd.DataFrame(rows)


def fit_logit(X: np.ndarray, y: np.ndarray, lr: float = 0.2,
              epochs: int = 1500, l2: float = 1e-3):
    mu, sd = X.mean(axis=0), X.std(axis=0) + 1e-9
    Xs = (X - mu) / sd
    w, b = np.zeros(X.shape[1]), 0.0
    for _ in range(epochs):
        p = 1.0 / (1.0 + np.exp(-np.clip(Xs @ w + b, -30, 30)))
        w -= lr * (Xs.T @ (p - y) / len(y) + l2 * w)
        b -= lr * float(np.mean(p - y))
    return w, b, mu, sd


def predict_logit(model, X: np.ndarray) -> np.ndarray:
    w, b, mu, sd = model
    z = ((X - mu) / sd) @ w + b
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def event_weights(prices: pd.DataFrame, events: pd.DataFrame,
                  use_meta: bool, horizon: int = 5) -> pd.DataFrame:
    """事件日建仓，持有 horizon 个交易日。"""
    w = pd.DataFrame(0.0, index=prices.index, columns=prices.columns)
    index = prices.index
    for _, row in events.iterrows():
        if use_meta:
            p = float(row["p"])
            if p <= 0.52:
                continue
            size = row["side"] * (2.0 * p - 1.0)
        else:
            size = row["side"]

        pos = index.get_loc(row["date"])
        col = w.columns.get_loc(row["asset"])
        for k in range(horizon):
            if pos + k < len(index):
                # 每个信号只分配 1/N 的资金，避免少数标的事件把仓位打满
                w.iloc[pos + k, col] += size / len(prices.columns)

    gross = w.abs().sum(axis=1)
    scale = gross.clip(upper=1.0) / gross.replace(0.0, np.nan)
    return w.mul(scale.fillna(1.0), axis=0).fillna(0.0)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    events = build_events(prices)

    split = int(len(events) * 0.5)
    train, test = events.iloc[:split], events.iloc[split:].copy()

    Xtr = train[["mom", "vol", "trend", "disp"]].values
    ytr = train["label"].values.astype(float)
    model = fit_logit(Xtr, ytr)
    test["p"] = predict_logit(model, test[["mom", "vol", "trend", "disp"]].values)

    w_base = event_weights(prices, test.drop(columns="p"), use_meta=False)
    w_meta = event_weights(prices, test, use_meta=True)

    base = backtest(rets, w_base, cost_bps=5.0)
    meta = backtest(rets, w_meta, cost_bps=5.0)
    base_sharpe = summarize("primary", base)["sharpe"]
    res = summarize("元标记（Meta-labeling）", meta,
                    note=f"二级逻辑回归，阈值 0.52；一级夏普 {base_sharpe:.2f}")
    if verbose:
        print(res)
        print("一级模型夏普:", round(base_sharpe, 3))
        print("二级模型触发比例:", round(float((test["p"] > 0.52).mean()), 3))
    return res


if __name__ == "__main__":
    demo()
