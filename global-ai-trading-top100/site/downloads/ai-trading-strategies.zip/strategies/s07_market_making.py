# -*- coding: utf-8 -*-
"""07 做市：Avellaneda-Stoikov 模型

原理
----
做市商同时报买价与卖价，赚取价差，但会积累库存风险。Avellaneda &
Stoikov (2008) 把做市写成随机最优控制问题：给定库存 q、剩余时间 T-t、
波动率 sigma 和风险厌恶 gamma，最优报价围绕“保留价格”展开。

公式
----
    保留价格:  r(s, q, t) = s - q * gamma * sigma^2 * (T - t)
    最优价差:  delta = gamma * sigma^2 * (T - t) + (2/gamma) * ln(1 + gamma/kappa)
    买价:      bid = r - delta/2
    卖价:      ask = r + delta/2
    成交强度:  lambda(delta) = A * exp(-kappa * delta)

其中 kappa 是订单簿深度参数：报价离中间价越远，成交概率越低。

本文件用蒙特卡洛仿真比较“库存感知报价”与“固定价差报价”。
这不是历史回测，只用于展示模型机制。
"""
from __future__ import annotations

import numpy as np

from .common import synthetic_prices  # noqa: F401  (保持包内风格一致)


def _quote_as(s: float, q: float, tau: float, gamma: float,
              sigma: float, kappa: float) -> tuple[float, float]:
    reservation = s - q * gamma * sigma ** 2 * tau
    spread = gamma * sigma ** 2 * tau + (2.0 / gamma) * np.log(1.0 + gamma / kappa)
    return reservation - spread / 2.0, reservation + spread / 2.0


def simulate(strategy: str = "as", n_paths: int = 400, n_steps: int = 100,
             seed: int = 0, gamma: float = 2.0, sigma: float = 0.05,
             kappa: float = 20.0, fixed_half_spread: float = 0.05) -> dict:
    rng = np.random.default_rng(seed)
    dt = 1.0 / n_steps
    pnls = np.zeros(n_paths)
    inv_rms = np.zeros(n_paths)

    for p in range(n_paths):
        s = 100.0
        q = 0.0
        cash = 0.0
        sq = 0.0
        for i in range(n_steps):
            tau = (n_steps - i) / n_steps
            if strategy == "as":
                bid, ask = _quote_as(s, q, tau, gamma, sigma, kappa)
            else:
                bid, ask = s - fixed_half_spread, s + fixed_half_spread

            # 成交概率随报价距离指数衰减
            p_bid = min(0.9, 0.5 * np.exp(-kappa * max(s - bid, 0.0)))
            p_ask = min(0.9, 0.5 * np.exp(-kappa * max(ask - s, 0.0)))

            if rng.random() < p_bid:
                q += 1.0
                cash -= bid
            if rng.random() < p_ask:
                q -= 1.0
                cash += ask

            s *= np.exp(rng.normal(0.0, sigma * np.sqrt(dt)))
            sq += q * q

        pnls[p] = cash + q * s
        inv_rms[p] = np.sqrt(sq / n_steps)

    sharpe = float(pnls.mean() / pnls.std()) if pnls.std() > 0 else 0.0
    return dict(name=f"做市（{strategy.upper()}）", type="仿真",
                ann_ret=0.0, ann_vol=float(pnls.std()), sharpe=sharpe,
                max_dd=0.0, turnover=0.0, mean_pnl=float(pnls.mean()),
                key=f"{pnls.mean():.2f}",
                note=f"每路径均值 {pnls.mean():.2f}，库存 RMS {inv_rms.mean():.2f}")


def demo(verbose: bool = True) -> dict:
    as_res = simulate("as")
    fixed_res = simulate("fixed")
    res = dict(as_res)
    res["name"] = "做市 A-S vs 固定价差"
    res["note"] = (f"A-S 均值 {as_res['mean_pnl']:.2f}（库存 RMS 已计入）"
                   f"；固定价差均值 {fixed_res['mean_pnl']:.2f}")
    if verbose:
        print(as_res)
        print(fixed_res)
    return res


if __name__ == "__main__":
    demo()
