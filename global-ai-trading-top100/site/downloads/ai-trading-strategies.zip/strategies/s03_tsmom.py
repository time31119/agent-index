# -*- coding: utf-8 -*-
"""03 时序动量 / 趋势跟踪（Time-series Momentum, TSMOM）

原理
----
Moskowitz, Ooi & Pedersen (2012)：资产自身过去 12 个月的收益方向，
可以预测其未来 1 个月的方向。对每个资产独立取符号，再用波动率倒数
分配仓位，使每个资产的风险贡献大致相等。

公式
----
    signal_i = sign(P_{i,t} / P_{i,t-252} - 1)
    w_i = signal_i * (sigma_target / sigma_i) / N
    sigma_i = std(r_i, 60) * sqrt(252)

风险
----
震荡市中反复止损（whipsaw）；趋势反转时回撤集中；
杠杆随波动率下降而上升，需设置杠杆上限。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, normalize_gross, rebalance_every, returns_of,
                     summarize, synthetic_prices, hold_mask)


def signals(prices: pd.DataFrame, lookback: int = 252, vol_window: int = 60,
            target_vol: float = 0.10, every: int = 5) -> pd.DataFrame:
    ret = returns_of(prices)
    direction = np.sign(prices / prices.shift(lookback) - 1.0)
    vol = (ret.rolling(vol_window).std() * np.sqrt(252)).replace(0.0, np.nan)

    raw = direction * (target_vol / vol)
    raw = raw.clip(-3.0, 3.0)
    w = normalize_gross(raw, 1.0)

    mask = rebalance_every(prices.index, every)
    return hold_mask(w, mask)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    w = signals(prices)
    bt = backtest(rets, w, cost_bps=3.0)
    res = summarize("时序动量 TSMOM", bt, note="12 个月方向 + 10% 波动率目标")
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
