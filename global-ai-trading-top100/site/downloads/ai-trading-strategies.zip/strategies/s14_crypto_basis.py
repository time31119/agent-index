# -*- coding: utf-8 -*-
"""14 加密基差 / 资金费率（Cash-and-Carry Basis）

原理
----
永续合约通过资金费率（funding）锚定现货。当资金费率为正，多头向空头
支付费用。做多现货、做空永续，可以赚取资金费，同时几乎不对价格方向
暴露。收益主要来自：
    carry = funding - Δbasis - 交易/资金成本
其中 basis = (Perp - Spot) / Spot。

风险
----
交易所对手方风险、提币限制、保证金与强平、basis 突然走阔、
资金费率转负、监管变化。这是“低波动、尾部风险大”的典型策略。
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def simulate(n_days: int = 730, seed: int = 11) -> dict:
    rng = np.random.default_rng(seed)
    spot_ret = rng.normal(0.0004, 0.035, n_days)
    spot = 30000.0 * np.exp(np.cumsum(spot_ret))

    basis = np.zeros(n_days)
    funding = np.zeros(n_days)
    for t in range(1, n_days):
        basis[t] = 0.95 * basis[t - 1] + rng.normal(0.0, 0.0008)
        funding[t] = float(np.clip(0.00008 + 0.3 * basis[t - 1]
                                   + rng.normal(0.0, 0.00008), -0.0002, 0.0008))

    basis_change = np.diff(basis, prepend=basis[0])
    carry = pd.Series(funding - basis_change - 0.00003)   # 每日再平衡成本

    ann = float((1.0 + carry).prod() ** (365 / len(carry)) - 1.0)
    vol = float(carry.std() * np.sqrt(365))
    sharpe = float(carry.mean() / carry.std() * np.sqrt(365)) if carry.std() > 0 else 0.0
    eq = (1.0 + carry).cumprod()
    mdd = float((eq / eq.cummax() - 1.0).min())

    return dict(name="加密基差 / 资金费率", type="回测", ann_ret=ann,
                ann_vol=vol, sharpe=sharpe, max_dd=mdd, turnover=0.0,
                note=f"日均资金费 {funding.mean()*1e4:.2f}bp，日均 carry {carry.mean()*1e4:.2f}bp")


def demo(verbose: bool = True) -> dict:
    res = simulate()
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
