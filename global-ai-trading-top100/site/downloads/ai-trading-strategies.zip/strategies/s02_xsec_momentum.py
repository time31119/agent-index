# -*- coding: utf-8 -*-
"""02 横截面动量（Cross-sectional Momentum）

原理
----
Jegadeesh & Titman (1993)：过去 3-12 个月表现好的股票，未来 1-12 个月
仍倾向于跑赢。剔除最近一个月（短期反转），按 12-1 收益率排序，做多
赢家组合、做空输家组合，市场中性。

公式
----
    score_i = P_{i,t-21} / P_{i,t-252} - 1
    w_i = rank(score_i) - 0.5   （截面去中心化）
    再按 60 日波动率倒数缩放，控制风险贡献

风险
----
动量崩溃（momentum crash）：市场急跌后反转，空头腿暴涨；
高换手带来成本；拥挤交易导致回撤放大。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, cs_rank, hold_mask, normalize_gross,
                     rebalance_every, returns_of, summarize, synthetic_prices)


def signals(prices: pd.DataFrame, lookback: int = 252, skip: int = 21,
            vol_window: int = 60, every: int = 5) -> pd.DataFrame:
    ret = returns_of(prices)
    mom = prices.shift(skip) / prices.shift(lookback) - 1.0
    vol = ret.rolling(vol_window).std().replace(0.0, np.nan)

    risk_adj = mom / vol
    ranks = cs_rank(risk_adj)
    w = normalize_gross(ranks, 1.0)

    # 每 5 个交易日调仓，其余时间持有
    mask = rebalance_every(prices.index, every)
    return hold_mask(w, mask)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    w = signals(prices)
    bt = backtest(rets, w, cost_bps=5.0)
    res = summarize("横截面动量 12-1", bt, note="周频调仓，波动率缩放")
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
