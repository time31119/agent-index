# -*- coding: utf-8 -*-
"""04 短期均值回归（Short-term Mean Reversion / OU）

原理
----
把价格（或价差）建模为 Ornstein-Uhlenbeck 过程：
    dX_t = theta * (mu - X_t) dt + sigma dW_t
偏离均值越远，回归速度越快；用 z-score 衡量偏离程度，反向开仓。
仅当估计的半衰期足够短（例如 < 30 日）时才交易，避免“价值陷阱”。

公式
----
    z_t = (X_t - MA_n) / std_n
    position = -clip(z_t, -3, 3) / 3
    HL = ln(2) / theta

风险
----
趋势行情中不断逆势加仓；波动率突变导致 z-score 失真；
开盘跳空与交易成本会吞掉薄利。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, hold_mask, normalize_gross, rebalance_every,
                     returns_of, summarize, synthetic_prices, zscore)


def signals(prices: pd.DataFrame, z_window: int = 10, entry: float = 1.5,
            vol_window: int = 60, every: int = 1) -> pd.DataFrame:
    lp = np.log(prices)
    z = zscore(lp, z_window)

    raw = -z.clip(-3.0, 3.0) / 3.0
    raw = raw.where(z.abs() > entry, 0.0)          # 死区，降低换手

    vol = returns_of(prices).rolling(vol_window).std().replace(0.0, np.nan)
    scaled = raw / vol
    w = normalize_gross(scaled, 1.0)

    mask = rebalance_every(prices.index, every)
    return hold_mask(w, mask)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    w = signals(prices)
    bt = backtest(rets, w, cost_bps=2.0)
    res = summarize("短期均值回归（OU）", bt, note="10 日 z-score，日频调仓")
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
