# -*- coding: utf-8 -*-
"""公共工具：合成数据、向量化回测、绩效指标。

所有策略模块只依赖 numpy / pandas，保证在最小环境中可运行。
合成数据仅用于验证代码管线，不代表真实市场，也不构成任何收益预期。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

TRADING_DAYS = 252


# --------------------------------------------------------------------------
# 数据
# --------------------------------------------------------------------------
def synthetic_prices(n_assets: int = 8, n_days: int = 1800, seed: int = 42,
                     start: str = "2014-01-02") -> pd.DataFrame:
    """生成带市场因子、行业因子、短期反转与一组协整关系的合成价格。

    结构：
      r_it = beta_i * market_t + sector_t + trend_it + idio_it
      并令 A1 = A0 * exp(OU 价差)，从而 A0/A1 构成协整对。
    """
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start, periods=n_days)

    n_reg = int(np.ceil(n_days / 150))
    regimes = rng.choice([0.7, 1.0, 1.5], size=n_reg, p=[0.3, 0.5, 0.2])
    vol = np.repeat(regimes, 150)[:n_days]
    market = rng.normal(0.00025, 0.009, n_days) * vol

    sector = rng.normal(0.0, 0.004, n_days)
    betas = rng.uniform(0.6, 1.4, n_assets)
    sector_load = rng.uniform(-0.4, 0.8, n_assets)

    # 缓慢漂移的个股趋势，制造弱动量
    trend = np.zeros((n_days, n_assets))
    for t in range(1, n_days):
        trend[t] = 0.990 * trend[t - 1] + rng.normal(0, 0.00015, n_assets)

    idio = rng.normal(0, 0.010, (n_days, n_assets))
    rets = (market[:, None] * betas[None, :]
            + sector[:, None] * sector_load[None, :]
            + trend + idio)

    # 一阶短期反转成分
    rets[1:] -= 0.06 * idio[:-1]

    logp = np.log(100.0) + np.cumsum(rets, axis=0)

    # 个股层面的 OU 定价误差（半衰期约 10 个交易日），制造均值回归机会
    ou = np.zeros((n_days, n_assets))
    for t in range(1, n_days):
        ou[t] = 0.93 * ou[t - 1] + rng.normal(0, 0.0035, n_assets)
    ou[:, :2] = 0.0          # A0/A1 保持干净的协整关系
    logp += ou

    # 注入协整关系：A1 相对 A0 的价差是 OU 过程
    phi = 0.92
    spread = np.zeros(n_days)
    for t in range(1, n_days):
        spread[t] = phi * spread[t - 1] + rng.normal(0, 0.012)
    logp[:, 1] = logp[:, 0] + spread

    cols = [f"A{i}" for i in range(n_assets)]
    return pd.DataFrame(np.exp(logp), index=dates, columns=cols)


def synthetic_volume(prices: pd.DataFrame, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    base = rng.lognormal(13.0, 0.35, size=prices.shape)
    shock = prices.pct_change(fill_method=None).abs().fillna(0.0).values
    return pd.DataFrame(base * (1.0 + 8.0 * shock),
                        index=prices.index, columns=prices.columns)


def returns_of(prices: pd.DataFrame) -> pd.DataFrame:
    return prices.pct_change(fill_method=None).fillna(0.0)


# --------------------------------------------------------------------------
# 回测
# --------------------------------------------------------------------------
def backtest(returns: pd.DataFrame, weights: pd.DataFrame,
             cost_bps: float = 5.0) -> pd.DataFrame:
    """权重在 t 日收盘决定，作用于 t+1 日收益，避免前视。"""
    idx = returns.index.intersection(weights.index)
    r = returns.loc[idx]
    w = weights.loc[idx].fillna(0.0)
    w_eff = w.shift(1).fillna(0.0)
    gross = (w_eff * r).sum(axis=1)
    turnover = (w - w.shift(1).fillna(0.0)).abs().sum(axis=1)
    cost = turnover * cost_bps / 1e4
    net = gross - cost
    return pd.DataFrame({"gross": gross, "net": net, "turnover": turnover})


def max_drawdown(net: pd.Series) -> float:
    eq = (1.0 + net.fillna(0.0)).cumprod()
    peak = eq.cummax()
    return float((eq / peak - 1.0).min()) if len(eq) else 0.0


def performance(net: pd.Series, turnover: pd.Series | None = None,
                name: str = "", kind: str = "回测", note: str = "") -> dict:
    net = net.dropna()
    if len(net) < 30 or float(net.std()) == 0.0:
        return dict(name=name, type=kind, ann_ret=0.0, ann_vol=0.0,
                    sharpe=0.0, max_dd=0.0, turnover=0.0, note=note or "样本不足")
    ann = float((1.0 + net).prod() ** (TRADING_DAYS / len(net)) - 1.0)
    vol = float(net.std() * np.sqrt(TRADING_DAYS))
    sharpe = float(net.mean() / net.std() * np.sqrt(TRADING_DAYS))
    mdd = max_drawdown(net)
    to = float(turnover.mean() * TRADING_DAYS) if turnover is not None else 0.0
    return dict(name=name, type=kind, ann_ret=ann, ann_vol=vol,
                sharpe=sharpe, max_dd=mdd, turnover=to, note=note)


def summarize(name: str, bt: pd.DataFrame, note: str = "") -> dict:
    return performance(bt["net"], bt["turnover"], name=name, note=note)


# --------------------------------------------------------------------------
# 信号工具
# --------------------------------------------------------------------------
def zscore(s: pd.Series | pd.DataFrame, window: int) -> pd.Series | pd.DataFrame:
    m = s.rolling(window, min_periods=max(5, window // 2)).mean()
    sd = s.rolling(window, min_periods=max(5, window // 2)).std()
    return (s - m) / sd.replace(0.0, np.nan)


def half_life(spread: pd.Series) -> float:
    """由 Δs_t = a + b s_{t-1} 估计 OU 半衰期：HL = -ln2 / b。"""
    s = spread.dropna()
    if len(s) < 30:
        return float("nan")
    y = s.diff().dropna()
    x = s.shift(1).dropna()
    x, y = x.align(y, join="inner")
    if len(x) < 20:
        return float("nan")
    b = float(np.polyfit(x.values, y.values, 1)[0])
    if b >= 0:
        return float("inf")
    return float(-np.log(2.0) / b)


def normalize_gross(w: pd.DataFrame, gross: float = 1.0) -> pd.DataFrame:
    denom = w.abs().sum(axis=1).replace(0.0, np.nan)
    return w.div(denom, axis=0).mul(gross).fillna(0.0)


def cs_rank(df: pd.DataFrame) -> pd.DataFrame:
    """截面百分位排名，映射到 [-0.5, 0.5]。"""
    return df.rank(axis=1, pct=True) - 0.5


def cs_zscore(df: pd.DataFrame) -> pd.DataFrame:
    mu = df.mean(axis=1)
    sd = df.std(axis=1).replace(0.0, np.nan)
    return df.sub(mu, axis=0).div(sd, axis=0)


def rebalance_every(index: pd.Index, every: int) -> pd.Series:
    mask = pd.Series(False, index=index)
    mask.iloc[::every] = True
    return mask


def hold_mask(w: pd.DataFrame, mask: pd.Series) -> pd.DataFrame:
    """只在 mask 为 True 的日期更新权重，其余日期沿用上一期。"""
    return w.where(mask, np.nan).ffill().fillna(0.0)


def ann_vol(returns: pd.DataFrame, window: int = 60) -> pd.DataFrame:
    return returns.rolling(window).std() * np.sqrt(TRADING_DAYS)


if __name__ == "__main__":
    px = synthetic_prices()
    print(px.tail())
    print("协整对 A0/A1 半衰期（日）:", round(half_life(np.log(px["A1"]) - np.log(px["A0"])), 2))
