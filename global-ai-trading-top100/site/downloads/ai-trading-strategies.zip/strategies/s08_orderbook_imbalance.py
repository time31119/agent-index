# -*- coding: utf-8 -*-
"""08 订单簿不平衡（Order Flow Imbalance, OFI）

原理
----
盘口买卖压力的变化会短期预测价格方向。Cont, Kukanov & Stoikov (2014)
定义的 OFI 把最优买卖价与挂单量的变化合成一个指标：

    e_n = 1{P^b_n >= P^b_{n-1}} q^b_n - 1{P^b_n <= P^b_{n-1}} q^b_{n-1}
        - 1{P^a_n <= P^a_{n-1}} q^a_n + 1{P^a_n >= P^a_{n-1}} q^a_{n-1}

OFI 为正表示买盘更强，价格短期倾向于上涨。策略在 OFI 突破阈值时
顺势持仓，持有数个单位时间后平仓。

本文件用带信息结构的合成订单流验证“信号→仓位→成本”的管线，
不是真实盘口回测。
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def simulate(n_steps: int = 30000, seed: int = 3, beta: float = 0.22,
             cost: float = 0.02) -> dict:
    rng = np.random.default_rng(seed)
    ofi = np.zeros(n_steps)
    ret = np.zeros(n_steps)

    for t in range(1, n_steps):
        ofi[t] = 0.90 * ofi[t - 1] + rng.normal(0.0, 1.0)
        ret[t] = beta * np.tanh(ofi[t - 1]) + rng.normal(0.0, 0.8)

    pos = np.where(ofi > 1.2, 1.0, np.where(ofi < -1.2, -1.0, 0.0))
    pnl = pos[:-1] * ret[1:] - cost * np.abs(np.diff(pos))

    # 用 OFI 预测下一期收益的 R^2
    x = np.tanh(ofi[:-1])
    y = ret[1:]
    coef = np.polyfit(x, y, 1)
    pred = np.polyval(coef, x)
    ss_res = float(((y - pred) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    tstat = float(pnl.mean() / pnl.std() * np.sqrt(len(pnl))) if pnl.std() > 0 else 0.0
    return dict(name="订单簿不平衡 OFI", type="仿真", ann_ret=0.0,
                ann_vol=float(pnl.std()), sharpe=0.0, max_dd=0.0,
                turnover=0.0, mean_pnl=float(pnl.sum()),
                key=f"t={tstat:.1f}",
                note=f"逐笔 t 值 {tstat:.1f}，OFI 预测 R²={r2:.4f}")


def demo(verbose: bool = True) -> dict:
    res = simulate()
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
