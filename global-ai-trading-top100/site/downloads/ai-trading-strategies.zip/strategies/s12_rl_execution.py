# -*- coding: utf-8 -*-
"""12 强化学习执行（RL Execution）

原理
----
把“如何在 T 个时段内卖完 Q 股”建模为马尔可夫决策过程：
    状态 s = (剩余时间 t, 剩余库存 q)
    动作 a = 本时段卖出比例
    奖励 r = 成交金额 - 库存风险惩罚
目标是最大化执行收益（最小化 implementation shortfall），在“一次性砸盘
造成冲击”与“拖到最后承担价格风险”之间权衡。本文件用表格 Q-learning
求解，并与 TWAP（每期等量卖出）对比。

公式
----
    Q(s,a) <- Q(s,a) + alpha [r + gamma max_a' Q(s',a') - Q(s,a)]
    临时冲击: 成交价 = S * (1 - eta * rate)
    永久冲击: S_{t+1} = S_t * exp(-gamma_p * rate + sigma * eps)

风险
----
仿真环境与真实市场差距大；Q 表离散化误差；只适用于小规模问题；
真实执行还要考虑排队、暗池、信息泄漏与合规。
"""
from __future__ import annotations

import numpy as np


class ExecutionEnv:
    """卖出 Q=1 单位、分 T 期的简化 Almgren-Chriss 环境。"""

    def __init__(self, T: int = 10, eta: float = 0.12, gamma_p: float = 0.02,
                 sigma: float = 0.01, lam: float = 0.0001, seed: int = 0):
        self.T, self.eta, self.gamma_p = T, eta, gamma_p
        self.sigma, self.lam, self.seed = sigma, lam, seed

    def reset(self):
        self.rng = np.random.default_rng(self.seed)
        self.t, self.inv, self.s = 0, 1.0, 100.0
        self.arrival, self.cash = 100.0, 0.0
        return self._state()

    def _state(self):
        return (min(self.t, self.T), int(round(self.inv * 10)))

    def step(self, action: int):
        frac = action * 0.1
        trade = min(self.inv, frac)
        rate = trade
        exec_price = self.s * (1.0 - self.eta * rate)
        proceeds = trade * exec_price
        self.cash += proceeds
        self.inv -= trade

        self.s *= np.exp(-self.gamma_p * rate + self.rng.normal(0.0, self.sigma))
        reward = proceeds - self.lam * self.inv * self.s
        self.t += 1
        done = self.t >= self.T
        if done:
            reward += self.inv * self.s * (1.0 - self.eta * self.inv)
            self.cash += self.inv * self.s * (1.0 - self.eta * self.inv)
            self.inv = 0.0
        return self._state(), float(reward), done


def train(n_episodes: int = 4000, seed: int = 1) -> np.ndarray:
    T, n_inv, n_act = 10, 11, 5
    Q = np.zeros((T + 1, n_inv, n_act))
    rng = np.random.default_rng(seed)
    alpha, eps = 0.15, 1.0

    for ep in range(n_episodes):
        env = ExecutionEnv(seed=seed + ep)
        s = env.reset()
        done = False
        while not done:
            if rng.random() < eps:
                a = int(rng.integers(0, n_act))
            else:
                a = int(np.argmax(Q[s[0], s[1]]))
            s2, r, done = env.step(a)
            target = r + (0.0 if done else 0.99 * float(np.max(Q[s2[0], s2[1]])))
            Q[s[0], s[1], a] += alpha * (target - Q[s[0], s[1], a])
            s = s2
        eps = max(0.05, eps * 0.999)
    return Q


def run_policy(policy, seed: int) -> float:
    env = ExecutionEnv(seed=seed)
    s = env.reset()
    done = False
    while not done:
        a = policy(s)
        s, _, done = env.step(a)
    return (env.arrival * 1.0 - env.cash) / env.arrival * 1e4   # 基点


def demo(verbose: bool = True) -> dict:
    Q = train()
    q_policy = lambda s: int(np.argmax(Q[s[0], s[1]]))
    twap_policy = lambda s: 1 if s[1] > 0 else 0

    q_is = np.array([run_policy(q_policy, 10_000 + i) for i in range(300)])
    t_is = np.array([run_policy(twap_policy, 10_000 + i) for i in range(300)])

    res = dict(name="RL 执行（Q-learning）", type="仿真", ann_ret=0.0,
               ann_vol=float(q_is.std()), sharpe=0.0, max_dd=0.0, turnover=0.0,
               mean_pnl=float(q_is.mean()), key=f"{q_is.mean():.0f}bp",
               note=(f"Q 策略 IS={q_is.mean():.2f}bp vs TWAP={t_is.mean():.2f}bp"
                     f"（越低成本；一次性卖出约 1200bp）"))
    if verbose:
        print(res)
        print("Q 策略示意:", [int(np.argmax(Q[t, 10 - t])) for t in range(10)])
    return res


if __name__ == "__main__":
    demo()
