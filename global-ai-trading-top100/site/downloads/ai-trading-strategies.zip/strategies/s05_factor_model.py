# -*- coding: utf-8 -*-
"""05 多因子模型（Multi-factor Scoring）

原理
----
把股票收益分解为共同因子与特质收益：
    r_i = alpha_i + sum_k beta_ik f_k + e_i
在多因子框架下，把多个经过验证的信号（动量、反转、低波、趋势）做
截面标准化后合成一个分数，做多高分、做空低分，保持市场中性。

公式
----
    score_i = sum_k z_k(signal_ik) / K
    w_i = rank(score_i) - 0.5
    IC = corr(score_t, r_{t+1})      信息系数
    IR = mean(IC) / std(IC) * sqrt(N)

风险
----
因子拥挤、因子失效、行业暴露；合成权重等权未必最优，
需要用 IC/IR 或机器学习方法做动态加权。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, cs_rank, cs_zscore, hold_mask, normalize_gross,
                     rebalance_every, returns_of, summarize, synthetic_prices)


def factor_panel(prices: pd.DataFrame) -> dict[str, pd.DataFrame]:
    ret = returns_of(prices)
    return {
        "momentum": prices.pct_change(252, fill_method=None).shift(21),
        "reversal": -prices.pct_change(5, fill_method=None),
        "low_vol": -ret.rolling(60).std(),
        "trend": prices / prices.rolling(200).mean() - 1.0,
    }


def signals(prices: pd.DataFrame, every: int = 5) -> pd.DataFrame:
    factors = factor_panel(prices)
    score = sum(cs_zscore(f).fillna(0.0) for f in factors.values())
    ranks = cs_rank(score)
    w = normalize_gross(ranks, 1.0)
    mask = rebalance_every(prices.index, every)
    return hold_mask(w, mask)


def information_coefficient(prices: pd.DataFrame, horizon: int = 5) -> pd.Series:
    """计算因子合成分数与未来收益的截面相关系数。"""
    factors = factor_panel(prices)
    score = sum(cs_zscore(f).fillna(0.0) for f in factors.values())
    fwd = prices.shift(-horizon) / prices - 1.0
    return score.corrwith(fwd, axis=1)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    w = signals(prices)
    bt = backtest(rets, w, cost_bps=5.0)
    ic = information_coefficient(prices).dropna()
    ir = float(ic.mean() / ic.std() * np.sqrt(252 / 5)) if ic.std() > 0 else 0.0
    res = summarize("多因子打分模型", bt, note=f"IC={ic.mean():.3f}, IR={ir:.2f}")
    if verbose:
        print(res)
    return res


if __name__ == "__main__":
    demo()
