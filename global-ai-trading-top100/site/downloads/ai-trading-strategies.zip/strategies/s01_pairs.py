# -*- coding: utf-8 -*-
"""01 配对交易（Pairs Trading / Cointegration）

原理
----
若两只股票的（对数）价格存在长期均衡关系
    y_t = alpha + beta * x_t + e_t,   e_t ~ I(0)
则价差 e_t 会围绕均值回复。对 e_t 做 z-score，偏离过大时做多低估腿、
做空高估腿，回归后平仓。经典实现见 Gatev, Goetzmann & Rouwenhorst (2006)。

关键公式
--------
    价差:      s_t = log(P_y,t) - alpha - beta * log(P_x,t)
    滚动对冲:  beta_t = Cov(y, x) / Var(x)  （250 日窗口）
    信号:      z_t = (s_t - mean(s)) / std(s)
    OU 半衰期: HL = -ln(2) / b,  b 来自 Δs_t = a + b s_{t-1}

实现要点
--------
1) 必须先判断协整方向：把随机游走腿当成被解释变量，残差会带单位根；
2) 对冲比例不宜高频重估，否则价差会被“估计噪声”污染；
3) 价差回归要带截距，否则 beta 有偏。

风险
----
协整关系可能结构性断裂；财报、并购、指数调整都会让价差长期不回归。
真实交易还需考虑融券成本、停牌、涨跌停与冲击成本。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (backtest, half_life, normalize_gross, rebalance_every,
                     returns_of, summarize, synthetic_prices, zscore)


def select_pair(prices: pd.DataFrame, lookback: int = 250) -> tuple[int, int]:
    """仅用前 lookback 天选择相关性最高的一对，避免使用未来信息。"""
    lp = np.log(prices.iloc[:lookback])
    cols = prices.columns
    best = (-np.inf, 0, 1)
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            c = float(lp[cols[i]].corr(lp[cols[j]]))
            if c > best[0]:
                best = (c, i, j)
    return best[1], best[2]


def rolling_ols(y: pd.Series, x: pd.Series, window: int = 250) -> tuple[pd.Series, pd.Series]:
    """滚动 OLS：y = alpha + beta x + e。"""
    cov = y.rolling(window).cov(x)
    var = x.rolling(window).var()
    beta = cov / var.replace(0.0, np.nan)
    alpha = y.rolling(window).mean() - beta * x.rolling(window).mean()
    return alpha, beta


def _oriented_pair(prices: pd.DataFrame, i: int, j: int,
                   lookback: int = 750) -> tuple[int, int, float, float]:
    """在 formation window 上判断协整方向，并返回 (dep, indep, alpha, beta)。"""
    a = np.log(prices.iloc[:lookback, i].values)
    b = np.log(prices.iloc[:lookback, j].values)

    beta_ba, alpha_ba = np.polyfit(a, b, 1)   # b on a
    beta_ab, alpha_ab = np.polyfit(b, a, 1)   # a on b

    hl_ba = half_life(pd.Series(b - alpha_ba - beta_ba * a))
    hl_ab = half_life(pd.Series(a - alpha_ab - beta_ab * b))

    if hl_ba <= hl_ab:
        return j, i, float(alpha_ba), float(beta_ba)
    return i, j, float(alpha_ab), float(beta_ab)


def signals(prices: pd.DataFrame, entry: float = 2.0, exit_z: float = 0.5,
            z_window: int = 60, beta_window: int = 750,
            beta_update: int = 250) -> pd.DataFrame:
    i, j = select_pair(prices)
    dep, indep, alpha0, beta0 = _oriented_pair(prices, i, j)

    y = np.log(prices.iloc[:, dep])
    x = np.log(prices.iloc[:, indep])

    # 对冲比例按年重估，避免估计噪声把价差变成随机游走
    alpha, beta = rolling_ols(y, x, beta_window)
    mask = rebalance_every(prices.index, beta_update)
    alpha = alpha.where(mask, np.nan).ffill().fillna(alpha0)
    beta = beta.where(mask, np.nan).ffill().fillna(beta0)

    spread = y - alpha - beta * x
    z = zscore(spread, z_window)

    state = np.zeros(len(prices))
    pos = 0
    for t in range(len(prices)):
        zt = float(z.iloc[t]) if np.isfinite(z.iloc[t]) else np.nan
        if not np.isfinite(zt):
            pos = 0
        elif pos == 0:
            if zt > entry:
                pos = -1          # 价差过高：空 y、多 x
            elif zt < -entry:
                pos = 1
        elif pos == 1 and zt > -exit_z:
            pos = 0
        elif pos == -1 and zt < exit_z:
            pos = 0
        state[t] = pos

    w = pd.DataFrame(0.0, index=prices.index, columns=prices.columns)
    w.iloc[:, dep] = state
    w.iloc[:, indep] = -state * beta.values
    return normalize_gross(w, 1.0)


def demo(verbose: bool = True) -> dict:
    prices = synthetic_prices()
    rets = returns_of(prices)
    w = signals(prices)
    bt = backtest(rets, w, cost_bps=3.0)

    i, j = select_pair(prices)
    dep, indep, alpha0, beta0 = _oriented_pair(prices, i, j)
    y = np.log(prices.iloc[:, dep])
    x = np.log(prices.iloc[:, indep])
    spread = y - alpha0 - beta0 * x
    hl = half_life(spread)

    res = summarize("配对交易（协整）", bt,
                    note=(f"{prices.columns[dep]}/{prices.columns[indep]}，"
                          f"beta={beta0:.2f}，半衰期 {hl:.1f} 日"))
    if verbose:
        print(res)
        print(bt.tail())
    return res


if __name__ == "__main__":
    demo()
