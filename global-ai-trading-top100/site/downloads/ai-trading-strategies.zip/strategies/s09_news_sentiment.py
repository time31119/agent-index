# -*- coding: utf-8 -*-
"""09 新闻情绪 NLP（News Sentiment）

原理
----
把文本转成情绪分数，再映射为仓位。常见做法：
  1) 词典法：统计正负词数量（Loughran-McDonald 金融词典）；
  2) 监督学习：用标注数据训练文本分类器；
  3) LLM：用大模型做事件抽取与情绪判断（需控制延迟与成本）。

本文件实现一个可解释的词典打分器，并用合成“新闻→收益”过程验证管线：
    s_t = 0.9 s_{t-1} + noise
    r_{t+1} = 0.15 * s_t + noise
    position_t = tanh(s_t / 2)

风险
----
反讽、否定、旧闻重发、标题党；情绪因子衰减极快；
LLM 的幻觉与合规风险；新闻授权与延迟。
"""
from __future__ import annotations

import numpy as np
import pandas as pd

POS_WORDS = ["beat", "beats", "upgrade", "record", "growth", "profit", "surge",
             "raise", "strong", "outperform", "buyback", "dividend", "win"]
NEG_WORDS = ["miss", "misses", "downgrade", "loss", "lawsuit", "probe", "cut",
             "weak", "warning", "fraud", "recall", "default", "plunge"]
POS_CN = ["超预期", "增长", "回购", "分红", "上调", "中标", "创新高", "盈利"]
NEG_CN = ["低于预期", "亏损", "下调", "诉讼", "调查", "减持", "违约", "暴跌"]


def score_text(text: str) -> float:
    """返回 [-1, 1] 的情绪分数；正负词加权，中文按子串计数。"""
    low = text.lower()
    tokens = low.replace(",", " ").replace(".", " ").split()
    pos = sum(t in POS_WORDS for t in tokens) + sum(w in text for w in POS_CN)
    neg = sum(t in NEG_WORDS for t in tokens) + sum(w in text for w in NEG_CN)
    return float((pos - neg) / (pos + neg + 1.0))


def aggregate(news: pd.DataFrame) -> pd.Series:
    """news: index=日期, columns=[text, weight]；按日加权平均。"""
    s = news.apply(lambda r: score_text(str(r["text"])) * float(r.get("weight", 1.0)), axis=1)
    return s.groupby(level=0).sum() / news.groupby(level=0)["weight"].sum()


def simulate(n_days: int = 1200, seed: int = 9, beta: float = 0.0015) -> dict:
    rng = np.random.default_rng(seed)
    sent = np.zeros(n_days)
    ret = np.zeros(n_days)
    for t in range(1, n_days):
        sent[t] = 0.90 * sent[t - 1] + rng.normal(0.0, 0.35)
        ret[t] = beta * sent[t - 1] + rng.normal(0.0, 0.010)

    pos = np.tanh(sent / 2.0)
    pnl = pd.Series(pos[:-1] * ret[1:] - 0.0002 * np.abs(np.diff(pos)))
    sharpe = float(pnl.mean() / pnl.std() * np.sqrt(252)) if pnl.std() > 0 else 0.0
    ann = float((1 + pnl).prod() ** (252 / len(pnl)) - 1)

    demo_news = pd.DataFrame(
        {"text": ["公司业绩超预期，宣布回购", "Company beats estimates, upgrade to buy",
                  "监管调查导致股价暴跌", "Weak outlook, downgrade"],
         "weight": [1.0, 1.0, 1.0, 1.0]},
        index=pd.to_datetime(["2025-01-02", "2025-01-02", "2025-01-03", "2025-01-03"]),
    )
    return dict(name="新闻情绪 NLP", type="回测", ann_ret=ann,
                ann_vol=float(pnl.std() * np.sqrt(252)), sharpe=sharpe,
                max_dd=float((1 + pnl).cumprod().div((1 + pnl).cumprod().cummax()).min() - 1),
                turnover=0.0, note="词典法：正面示例 0.67，负面示例 -0.67")


def demo(verbose: bool = True) -> dict:
    res = simulate()
    if verbose:
        print(res)
        print(score_text("Company beats estimates and raises guidance"))
    return res


if __name__ == "__main__":
    demo()
