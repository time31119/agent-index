# 全球 AI 交易 TOP 100 与顶尖策略源代码

一份可复现的「人物 — 机构 — 策略 — 代码」研究报告。

## 内容

- **100 条编辑性榜单**：人物、机构、AI 原生系统与策略范式。
- **25 个策略族**：从统计套利、做市到加密基差与 MEV。
- **15 个可运行 Python 实现**：仅依赖 numpy / pandas。
- **独立静态网站**：`site/`，含榜单检索、策略地图、源码浏览与下载。
- **DOCX / XLSX / Markdown** 三种交付格式。

## 文件

```
data/top100.py                100 条榜单数据
strategies/common.py          合成数据、回测、绩效指标
strategies/s01_pairs.py ...   15 个策略模块
content/report_template.md    报告正文模板
site/                         独立静态网站
build_site.py                 生成站点数据与下载文件
build_report.py               生成 DOCX / XLSX / Markdown
run_all.py                    运行全部策略自检
output/                       生成结果
```

## 打开网站

```bash
python build_site.py
python -m http.server 8765 --directory site
# http://127.0.0.1:8765/
```

也可以直接双击 `site/index.html`。站点详情见 [site/README.md](site/README.md)。

## 快速开始

```bash
pip install numpy pandas python-docx openpyxl
python run_all.py
python build_report.py
```

## 合成数据自检结果

| 策略 | 年化 | 夏普 | 最大回撤 |
| --- | --- | --- | --- |
| 配对交易（协整） | 9.4% | 1.77 | -4.7% |
| 横截面动量 12-1 | 9.9% | 1.21 | -12.7% |
| 时序动量 TSMOM | 3.3% | 0.40 | -18.9% |
| 短期均值回归（OU） | 0.4% | 0.11 | -44.4% |
| 多因子打分模型 | 6.6% | 0.82 | -13.6% |
| PCA 残差反转 | 5.9% | 0.87 | -9.3% |
| 做市 A-S vs 固定价差 | — | — | — |
| 订单簿不平衡 OFI | — | — | — |
| 新闻情绪 NLP | 5.7% | 1.05 | -5.8% |
| 期权波动率套利 | — | — | — |
| GBDT 选股 | 6.0% | 0.83 | -8.6% |
| RL 执行（Q-learning） | — | — | — |
| 风险平价 + 分数凯利 | 5.4% | 0.43 | -31.2% |
| 加密基差 / 资金费率 | 5.5% | 2.90 | -2.1% |
| 元标记（Meta-labeling） | 0.1% | 0.36 | -1.3% |

> 以上结果来自合成数据，仅用于验证代码管线，不代表真实市场表现。
> 合成数据中植入了协整、动量、残差反转等结构，因此部分策略表现较好；
> 这不构成任何策略有效性的证据。

## 免责声明

本报告不是官方排名，不构成投资建议。代码仅供研究学习。
